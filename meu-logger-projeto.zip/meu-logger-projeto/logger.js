//logger.js - Sistema de Logger para nossa aplicação
//Este arquivo cria uma "classe" que sabe como salvar mensagens em arquivos

//1. IMPORTAÇÕES - Trazendo as ferramentas que vamos usar
const fs = require('fs').promises; //Sistema de arquivos 
const path = require('path'); //manipulação de caminhos

//2. CLASSE LOGGER - Nossa "fábrica" de logs
class Logger {
    //CONSTRUTOR- Executa quando criamos um novo Logger
    constructor(logFile = 'app.log'){
        //_dirname = pasta atual do arquivo
        //path.join = junta caminhos de forma segura
        this.logFile = path.join(__dirname, logFile);
        console.log(`📝 Logger criado! Arquivo: ${this.logFile}`);
    }

    //MÉTODO PRINCIPAL -Escreve qualquer tipo de log
    async log(message, level = 'INFO'){
        //Cria um "carimbo de data e hora" (tipo: 2024-01-15 às 10:30:45)
        const timestamp = new Date().toISOString();

        //Monta a linha do log: [DATA] NÍVEL: MENSAGEM
        const logEntry = `[${timestamp}] ${level}: ${message}\n`;

        try{ 
            //appendFile = "cola" no final do arquivo
            await fs.appendFile(this.logFile, logEntry);
            console.log(`✅ Log salvo: ${level} - ${message}`);
        } catch (error) {
            console.error('❌ Erro ao escrever log: ', error.message);
        }
    }
    //MÉTODO DE CONVINIÊNCIA - Para logs informativos
    async info(message){
        await this.log(message, 'INFO');
    }
    //MÉTODO DE CONVINIÊNCIA - Para logs de erro
    async error(message){
        await this.log(message, 'ERROR');
    }
    //MÉTODO EXTRA - Para logs de aviso
    async warn(message){
        await this.log(message,'WARN');
    }

}
//EXPORTA a classe para outros arquivos usarem
module.exports = Logger;