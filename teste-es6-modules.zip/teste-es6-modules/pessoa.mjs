//pessoa.js     
//JEITO 1: exportar itens individuais
export const nome= 'João';
export const idade= 30;
export function falar(){
    return `Olá, eu sou ${nome}`;
}
//Jeito 2: 
export default{
    nome: 'João',
    idade: 30,
    falar(){
        return`Olá, eu sou ${this.nome}`;
    }
};