//arquivo principal
//importa e sua as funções do math.js

//importando o módulo criado
const math = require('./math.js');

console.log('===TESTANDO NOSSO MÓDULO MATEMÁTICO===');

//Testando função somar
const resultadoSoma = math.somar(10, 5);
console.log('Resultado da soma: ',resultadoSoma);

//Testando função multiplicar
const resultadoMultiplicacao = math.multiplicar(4, 7);
console.log('Resultado da multiplicação: ',resultadoMultiplicacao);

//Testando função dividir
const resultadoDivisao = math.dividir(20, 4);
console.log('Resultado da divisão: ',resultadoDivisao);

//Divisão por zero
const divisaoPorZero = math.dividir(10, 0);
console.log('Divisão por zero: ',divisaoPorZero);

console.log('===TESTE CONCLUÍDO===');