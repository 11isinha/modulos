//test-logger.js - Arquivo para testar nosso logger
//ATENÇÃO: Este arquivo deve estar na MESMA PASTA que o logger.js

//LINHA 1: Importa nossa classe Logger do arquivo logger.js
//O './' significa "na mesma pasta que este arquivo"
const Logger = require('./logger');

//LINHA 2: Função que vai testar nosso logger
//'async' significa que esta função pode "esperar" outras operações
async function testarLogger(){
    console.log('🚀 Iniciando teste do Logger...');

//LINHA 3: Cria um novo logger que vai salvar no arquivo 'teste.log'
const logger = new Logger('teste.log');

//LINHA 4: Testa diferentes tipos de mensagem
//Cada linha vai aparecer no console e ser salva no arquivo
//IMPORTANTE: Usamos 'await' para esperar cada operação terminar
await logger.info('Aplicação iniciada com sucesso!');
await logger.warn('Esta é uma mensagem de aviso');
await logger.error('Simulando um erro de teste');

console.log('✅ Teste concluído Verifique o arquivo teste.log');
}

testarLogger();