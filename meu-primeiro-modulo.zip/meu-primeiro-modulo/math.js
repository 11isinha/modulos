//Módulo de operações matemáticas 

//somar dois números
function somar(a,b){
    console.log(`Somando ${a} + ${b}`);
    return a + b;
}

//multiplicar dois números 
function multiplicar(a, b){
    console.log(`Multiplicando ${a} * ${b}`);
    return a * b;
}

//dividir dois números
function dividir(a,b) {
    if (b===0){
        console.log('Erro: Não é possível dividir por zero!');
        return null;
    }
    console.log(`Dividindo ${a} / ${b}`);
    return a / b;
}

module.exports = {
    somar,
    multiplicar,
    dividir
};