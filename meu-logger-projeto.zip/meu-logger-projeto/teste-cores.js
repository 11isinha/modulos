//teste-cores.js

//IMPORTA o pacote que acabamos de instalar
const colors = require('colors');

//FUNÇÃO PRINCIPAL - testa diferentes cores
function testarCores(){
    console.log('🎨 Testando o pacote Colors!');
    console.log('');
//cores básicas
    console.log('Este texto é vermelho! '.red);
    console.log('Este texto é verde! '.green);
    console.log('Este texto é azul! '.blue);
    console.log('Este texto é amarelo! '.yellow);
    console.log('Este texto é magenta! '.magenta);
    console.log('Este texto é ciano! '.cyan);

    console.log('');

//estilos
console.log('Este texto está em negrito'.bold);
console.log('Este texto está sublinhado!'.underline);
console.log('Este texto está invertido'.inverse);

console.log('');

//cores e estilo
console.log('Texto com fundo vermelho'.bgRed);
console.log('Texto com fundo verde '.bgGreen);
console.log('Texto branco com fundo azul'.white.bgBlue);

console.log('');
console.log('🎉Teste concluído! Seu terminal agora tem cores!'.rainbow);

}

testarCores();